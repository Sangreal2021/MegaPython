#== 출력문 옵션 알아보기 ==#
# seperator: (,)사이 출력할 데이터들을 sep='내용'으로 연결
# default값은 sep=' '
print(2, 0, 2, 4) # sep=' '이 기본값
print(2, 0, 2, 4, sep='')
print('2024', '03', '16', sep='-')
print('시험 난이도: TOEFL', 'TOEIC', sep='>>>')
print('123+456', 123+456, sep='=')
print()

# end: 문자열의 마지막을 end='내용'으로 출력
# default값은 end='\n'
print('원주율:', 3.141, end='')
print(592)
print('3월 4월 5월', end='')
print()
print('6월 7월 8월')
print()

# sep, end 함께 사용하기
print(15, 27, sep='+', end='=')
print(15+27)

