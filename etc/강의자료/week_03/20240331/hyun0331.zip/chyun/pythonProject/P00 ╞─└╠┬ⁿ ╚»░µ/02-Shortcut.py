'''
1. 파이참 단축키
파일명 수정(Refactor-Rename): shift + F6
코드 자동정렬: ctrl + alt + L
한줄(영역) 이동: shift + alt + ↑,↓
한줄(영역) 복사: ctrl + D
한줄(영역) 삭제: ctrl + Y
다음줄 이동: shift + Enter
열선택하기: ctrl + ctrl + ↑,↓
영역 다중선택: alt + 마우스클릭
'''
num1 = 7.0
num2 = 3.0
print('num1 + num2 ===>>', num1 + num2)
print('num1 - num2 ===>>', num1 - num2)
print(" * num2 ===>>", num1 * num2)
print("num1 / num2 ===>>", num1 / num2)
print("num1 % num2 ===>>", num1 % num2)
print("num1 // num2 ===>>", num1 // num2)
print("num1 ** num2 ===>>", num1 ** num2)

