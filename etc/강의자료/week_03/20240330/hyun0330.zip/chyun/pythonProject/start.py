for i in range(3, -3, -1):
    num = 10/i
    print(num)