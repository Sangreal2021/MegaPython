'''
1. 파이참 단축키
파일명 수정(Refactor-Rename): shift + F6
코드 자동정렬: ctrl + alt + L
한줄(영역) 이동: shift + alt + ↑,↓
한줄(영역) 복사: ctrl + D
한줄(영역) 삭제: ctrl + Y


'''
for i in range(2, 10):  # i: 2단~9단 범위
    print(f'{i}단:', end=' ')
    print()