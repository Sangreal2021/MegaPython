'''
# 주석문(comments)
메모 또는 코드를 설명하는 용도. 코드실행X
한줄주석(#): ctrl + /
여러줄주석: 외따옴표 3쌍 or 쌍따옴표 3쌍

# 실행하기(Run)
현재 페이지 실행: ctrl + shift + F10

# 테마 및 글꼴 변경
폰트 크기 변경하기: File > Settings > Editor - Font  +마우스 컨트롤
테마 변경하기: File > Settings > Appearence > Theme (> Darcula)
색상 구성표 변경하기: File > Settings > Editor - Color Shcema (> Monokai)
주석 색상 변경하기: ../Color Schema > Python > Line Comment
여러줄 주석 색상 변경하기: ../Color Schema > Python > Docstring Text
초: 140, 185, 115
노: 210, 180, 90
'''
print('파이참 실행하기')
# print('파이참 실행') -> 한줄 주석 처리

print(1)
'''
여러줄 주석 처리
print(2)
print(3)
print(4)
'''
print(5)
# print(6)
# print(7)
print(8)

print('안녕')
# print('하세요'
# => 에러: 빨간줄이 표시되면 에러 발생. 실행X