# k = input()
# a = k.split()
# print(len(a))

print(len(input().split()))