print(10)
p = print
p(10)
display = print
display(2024,4,7,sep='-')