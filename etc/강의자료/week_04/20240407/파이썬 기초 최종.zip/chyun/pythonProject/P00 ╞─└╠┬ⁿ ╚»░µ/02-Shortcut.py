'''
1. 파이참 단축키
파일명 수정(Refactor-Rename): shift + F6
코드 자동정렬: ctrl + alt + L
한줄(영역) 이동: shift + alt + ↑,↓
한줄(영역) 복사: ctrl + D
한줄(영역) 삭제: ctrl + Y
다음줄 이동: shift + Enter
열선택하기: ctrl + ctrl + ↑,↓
영역 다중선택: alt + 마우스클릭

2. 윈도우 공통 단축키
다시 실행: ctrl + Z
영역 잘라내기/복사/붙여넣기: ctrl + X/C/V
전체 선택: ctrl + A
단어 찾기: ctrl + F

한줄 맨앞뒤 이동: home, end
단어 단위 이동: ctrl + ←,→
단어 단위 삭제: ctrl + delete/backspace
'''
a = 7.0
b = 3.0
print('a + b ===>>', a + b)
print('a - b ===>>', a - b)
print(" * b ===>>", a * b)
print("a / b ===>>", a / b)
print("a % b ===>>", a % b)
print("a // b ===>>", a // b)
print("a ** b ===>>", a ** b)

