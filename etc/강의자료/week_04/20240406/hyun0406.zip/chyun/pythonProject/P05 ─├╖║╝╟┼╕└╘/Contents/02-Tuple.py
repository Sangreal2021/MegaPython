'''
# 튜플(tuple)
튜플이름 = (데이터0, 데이터1, 데이터2..)
튜플 특징: 순서O, 중복O, 변경X
'''
a = (5, 10, 15, 10, 5)
b = (5, 10, 'Sun', 'day', 'Morning')
c = (0, True, ('Sun', 'day', 'Morning'))

print('a =', a, type(a))

# 튜플 인덱싱
print(a[1], a[-2])
print(a[2], a[-3])
print(b[2]+b[3])
print(c[0]+c[1])
print(c[-1][-1])
print()

# 튜플 슬라이싱
print(a[2:])
print(b[0:5:2]) # [시작값:끝값:증감값]
print(b[::2])
print(c[2][::2])
print()
################
d = (1,2,3,4,5)
e = (6,7,8)

f = d+e
print('f =', f)
g = e*3
print('g =', g)

# 튜플 데이터를 index로 찾기
print(g.index(7))
print(g.index(7, 2)) # 7값을 2번 인덱스부터 탐색

