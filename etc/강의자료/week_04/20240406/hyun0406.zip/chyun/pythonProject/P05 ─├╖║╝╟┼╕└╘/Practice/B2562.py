k = []
for i in range(9):
    num = int(input())
    k.append(num)
# print(k)

# 1. 반복문
# max = 0
# max_idx = -1
# for i in range(9):
#     if k[i]>max:
#         max = k[i]
#         max_idx = i
# print(max)
# print(max_idx+1)

# 2. 파이썬 함수 사용
print(max(k))
print(k.index(max(k))+1)