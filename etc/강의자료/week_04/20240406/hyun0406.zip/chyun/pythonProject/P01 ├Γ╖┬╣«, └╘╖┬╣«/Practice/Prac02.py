'''
Q)  input()으로 4개의 정보를 입력 받아
    사진과 같이 자기소개를 표현해보자.
    띄어쓰기, 줄바꿈 모두 사진과 동일하게 나타나도록 출력해보자.
'''
name = input('이름 입력: ')
age = input('나이 입력: ')
phone = input('번호 입력: ')
ment = input('멘트 입력: ')

print('**********자기소개**********')
print('이름:', name)
print('나이:', age)
print('번호:', phone)
print('멘트:', ment)





