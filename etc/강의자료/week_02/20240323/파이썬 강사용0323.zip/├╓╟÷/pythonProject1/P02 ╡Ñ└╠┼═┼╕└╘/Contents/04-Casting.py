'''
# 타입 변환(Type Casting)
'타입 변환' = '캐스팅' = '형변환'
    변환할타입(데이터)
'''
# 정수형 <- 실수형
num1 = int(3.14)
print('실수를 정수로 변환:', num1, type(num1))
# 타입 변환시 데이터 값도 함께 변경됨을 주의

# 실수형 <- 정수형
num2 = float(50)
print('정수를 실수로 변환:', num2, type(num2))

# 문자열 <- 실수형
msg = str(10.5)
print('실수를 문자열로 변환:', msg, type(msg))

# (에러)정수형 <- 문자열
# num0 = int('아메리카노')
# print(num0)

# 정수형 <- 문자열
num3 = int('401')
print('문자열을 정수로 변환:', num3, type(num3))

# 정수와 실수, 문자열의 연산
a = 10 # 정수
b = 25.0 # 실수
c = '100' # 문자열

# a+b
print(a+b) # 정수+실수=>실수
print(int(a+b))
print(str(a)+str(b)) # 문자열끼리 이어붙임

# b+c
# print(b+c)
print(b+float(c))
print(int(int(c)/b))
print()

# 논리형으로 타입 변환
print(bool(-10))
print(bool(0))
print(bool('김고은'))
print(bool(''))
if 't':
    print('조건문')