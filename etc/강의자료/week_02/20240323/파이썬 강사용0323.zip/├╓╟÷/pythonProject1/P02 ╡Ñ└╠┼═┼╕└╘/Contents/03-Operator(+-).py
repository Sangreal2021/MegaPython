'''
# 사칙 연산자
+ : 덧셈 연산자
- : 뺄셈
* : 곱셈

/ : 나눗셈 연산자 - 결과는 실수, 소수자리 포함
% : 나머지 연산자

//: 정수 나누기 연산자 - 소수점 이하 버림
**: 제곱 연산자
'''
print(10+20.5)
print(50-30)
print(10*50)
print()

print(3/2)
print(14%3)
print(11%3.5)
print()

print(3//2)
print(4**3)
print()

print(5/4)
print(4/2)
print(4//2)