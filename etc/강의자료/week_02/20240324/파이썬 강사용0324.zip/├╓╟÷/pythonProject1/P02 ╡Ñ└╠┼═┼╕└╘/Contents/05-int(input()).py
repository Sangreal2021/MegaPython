'''
# input()으로 입력 받은 문자열을 타입 변환
저장받을변수 = 변환할타입(input('입력멘트'))
'''
# 정수로 데이터를 입력받기
numA = int(input('정수 입력: '))
print('numA:', numA, type(numA))
print()

# 실수로 데이터를 입력받기
numB = float(input('실수 입력: '))
print('numB:', numB, type(numB))