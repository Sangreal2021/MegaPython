'''
1. 파이참 단축키
파일명 수정(Refactor-Rename): shift + F6
코드 자동정렬: ctrl + alt + L
'''
for i in range(2, 10):  # i: 2단~9단 범위
    print(f'{i}단:', end=' ')
    for j in range(1, 10):
        print(i * j, end=' ')
    print()