print('안녕하세요')
print('첫날입니다')