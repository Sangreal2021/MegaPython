'''
Q)  다음 두 실수가 주어졌을 때
    두 수 끼리 더하기, 빼기, 곱하기, 나누기,
    나머지 연산, 정수 나누기, 제곱 결과를 실행창에 출력해보자.

    ↓ 실행화면 ↓
	num1 + num2 = 10.0
    num1 - num2 = 4.0
    num1 * num2 = 21.0
    num1 / num2 = 2.3333333333333335
    num1 % num2 = 1.0
    num1 // num2 = 2.0
    num1 ** num2 = 343.0
'''
num1 = 7.0
num2 = 3
print('num1 + num2 =', num1 + num2)
print('num1 - num2 =', num1 - num2)
print('num1 * num2 =', num1 * num2)
print('num1 / num2 =', num1 / num2)
print('num1 % num2 =', num1 % num2)
print('num1 // num2 =', num1 // num2)
print('num1 ** num2 =', num1 ** num2)